Before running the commands below you should source the local .venv folder in the working directory with 

source ./.venv/bin/activate


To train StoRM on test noises:

cd StoRM

python train.py --format wsj0 --base_dir ./HRI/Seen_noises/Dataset --mode regen-joint-training

The checkpoint after training finishes will be found in /StoRM/.logs directory.
 
A pretrained checkpoint can be found at /StoRM/HRI/Seen_noises/epoch=134-pesq=0.00.ckpt
 
 
To train StoRM on noises different from test set:
 
Replace Seen_noises with Unseen_noises in the steps above. 

***************************************************************************************************************************

To test StoRM:

Navigate to /StoRM/HRI/Seen_noises/test_set

Select the folder with the desired SNR
Seclect the folder with the desired noise
Copy files from this folder into /StoRM/HRI/Seen_noises/Dataset/tt/noisy

Execute:

cd StoRM

python ./enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/noisy --ckpt ./HRI/Seen_noises/epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin

THe enhanced files are available in /StoRM/HRI/Seen_noises/Dataset/tt/clean 

To test a StoRM checkpoint on noises that were not seen at training time:

Replace the value of --ckpt above with ./HRI/Unseen_noises/epoch=134-pesq=0.00.ckpt


****************************************************************************************************************************


To test StoRM on all the noise types for a given SNR:

Navigate to the StoRM folder:

Then execute the ./copy_script_0.sh for 0dB SNR. 

The enhanced files will be available in ./HRI/Seen_noises/enhanced_set

****************************************************************************************************************************

To test DeepFilterNet 3 on our test set:

Navigate to DFNet3 folder from HRI_dataset folder. 


The files in the test folder will be enhanced and will be available in enhanced folder. 

*****************************************************************************************************************************

To transcribe using Whisper medium model and calculate WER:

Navigate to /HRI_dataset/Whisper. 

Run runall.sh to get transciptions for StoRM and DeepFilterNet 3 enhanced files in the same folders where the enhanced files are. 

To reproduce WER results, run the runall_wer.sh script in the /HRI_dataset/Whisper directory. The WER will be produced for each noise type and SNR in the wer.txt file in the same directory. 

*****************************************************************************************************************************
  
