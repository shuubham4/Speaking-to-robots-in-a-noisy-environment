cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/crowd
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/crowd/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/crowd/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l



cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/forest
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/forest/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/forest/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l



cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/heli
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/heli/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/heli/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l




cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/office
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/office/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/office/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l




cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/subway
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/subway/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/subway/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l




cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/bomb
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/bomb/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/bomb/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l




cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/burst
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/burst/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/burst/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l




cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/pistol
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/pistol/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/pistol/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l



cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/bullmastif
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/bullmastif/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/bullmastif/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l



cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/chihuahua
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/chihuahua/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/chihuahua/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l



cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/cooing
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/cooing/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/cooing/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l


cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/crying
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/crying/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/crying/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l


cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/doberman
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/doberman/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/doberman/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l


cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/german_shepherd
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/german_shepherd/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/german_shepherd/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l


cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/maltese
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/maltese/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/maltese/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l


cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/plane
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/plane/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/plane/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l


cd /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/traffic
for f in ./*.wav
do 
   cp -v /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises/-3/traffic/"${f}" /mnt/secondNVMe/storm-master/base_dir/tt/noisy/"${f}"
done
   cd /mnt/secondNVMe/storm-master 
   python enhancement.py --test_dir ./base_dir/tt/noisy --enhanced_dir ./base_dir/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./base_dir/tt/clean/*.wav
do 
   cp -v "${f}" /home/shuubham/Desktop/spine1_train/whisper_train/noisy_files/path_to_clips/test_more_noises_storm/-3/traffic/   
done
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/noisy/*.wav | wc -l
rm -vrf /mnt/secondNVMe/storm-master/base_dir/tt/clean/*.wav | wc -l
















