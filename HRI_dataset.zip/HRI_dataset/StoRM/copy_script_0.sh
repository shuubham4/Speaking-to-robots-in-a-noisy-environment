cd ./HRI/Seen_noises/test_set/0/crowd
for f in ./*.wav
do 
   cp -v "${f}" ../../../../Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../../
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./HRI/Seen_noises/epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/crowd/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l




cd ./HRI/Seen_noises/test_set/0/forest
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/forest/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/forest/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l



cd ./HRI/Seen_noises/test_set/0/heli
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/heli/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/heli/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l




cd ./HRI/Seen_noises/test_set/0/office
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/office/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/office/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l




cd ./HRI/Seen_noises/test_set/0/subway
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/subway/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/subway/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l




cd ./HRI/Seen_noises/test_set/0/bomb
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/bomb/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/bomb/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l



cd ./HRI/Seen_noises/test_set/0/burst
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/burst/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/burst/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l




cd ./HRI/Seen_noises/test_set/0/pistol
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/pistol/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/pistol/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l



cd ./HRI/Seen_noises/test_set/0/bullmastif
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/bullmastif/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/bullmastif/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l



cd ./HRI/Seen_noises/test_set/0/chihuahua
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/chihuahua/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/chihuahua/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l



cd ./HRI/Seen_noises/test_set/0/cooing
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/cooing/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/cooing/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l


cd ./HRI/Seen_noises/test_set/0/crying
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/crying/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/crying/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l


cd ./HRI/Seen_noises/test_set/0/doberman
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/doberman/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/doberman/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l


cd ./HRI/Seen_noises/test_set/0/german_shepherd
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/german_shepherd/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/german_shepherd/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l


cd ./HRI/Seen_noises/test_set/0/maltese
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/maltese/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/maltese/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l


cd ./HRI/Seen_noises/test_set/0/plane
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/plane/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/plane/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l


cd ./HRI/Seen_noises/test_set/0/traffic
for f in ./*.wav
do 
   cp -v ./HRI/Seen_noises/test_set/0/traffic/"${f}" ./HRI/Seen_noises/Dataset/tt/noisy/"${f}"
done
cd ../../../../..
python enhancement.py --test_dir ./HRI/Seen_noises/Dataset/tt/noisy --enhanced_dir ./HRI/Seen_noises/Dataset/tt/clean --ckpt ./epoch=134-pesq=0.00.ckpt --mode storm --corrector langevin
for f in ./HRI/Seen_noises/Dataset/tt/clean
do 
   cp -v "${f}" ./HRI/enhanced_set/0/traffic/   
done
rm -vrf ./HRI/Seen_noises/Dataset/tt/noisy/*.wav | wc -l
rm -vrf ./HRI/Seen_noises/Dataset/tt/clean/*.wav | wc -l











