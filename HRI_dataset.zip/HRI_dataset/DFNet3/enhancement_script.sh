python enhancement_script.py -3 bomb
python enhancement_script.py 0 bomb
python enhancement_script.py 3 bomb
python enhancement_script.py 6 bomb
python enhancement_script.py 12 bomb

python enhancement_script.py -3 crowd
python enhancement_script.py 0 crowd
python enhancement_script.py 3 crowd
python enhancement_script.py 6 crowd
python enhancement_script.py 12 crowd

python enhancement_script.py -3 forest
python enhancement_script.py 0 forest
python enhancement_script.py 3 forest
python enhancement_script.py 6 forest
python enhancement_script.py 12 forest

python enhancement_script.py -3 heli
python enhancement_script.py 0 heli
python enhancement_script.py 3 heli
python enhancement_script.py 6 heli
python enhancement_script.py 12 heli

python enhancement_script.py -3 bullmastif
python enhancement_script.py 0 bullmastif
python enhancement_script.py 3 bullmastif
python enhancement_script.py 6 bullmastif
python enhancement_script.py 12 bullmastif

python enhancement_script.py -3 burst
python enhancement_script.py 0 burst
python enhancement_script.py 3 burst
python enhancement_script.py 6 burst
python enhancement_script.py 12 burst

python enhancement_script.py -3 office
python enhancement_script.py 0 office
python enhancement_script.py 3 office
python enhancement_script.py 6 office
python enhancement_script.py 12 office

python enhancement_script.py -3 plane
python enhancement_script.py 0 plane
python enhancement_script.py 3 plane
python enhancement_script.py 6 plane
python enhancement_script.py 12 plane

python enhancement_script.py -3 subway
python enhancement_script.py 0 subway
python enhancement_script.py 3 subway
python enhancement_script.py 6 subway
python enhancement_script.py 12 subway

python enhancement_script.py -3 traffic
python enhancement_script.py 0 traffic
python enhancement_script.py 3 traffic
python enhancement_script.py 6 traffic
python enhancement_script.py 12 traffic


python enhancement_script.py -3 chihuahua
python enhancement_script.py 0 chihuahua
python enhancement_script.py 3 chihuahua
python enhancement_script.py 6 chihuahua
python enhancement_script.py 12 chihuahua


python enhancement_script.py -3 cooing
python enhancement_script.py 0 cooing
python enhancement_script.py 3 cooing
python enhancement_script.py 6 cooing
python enhancement_script.py 12 cooing


python enhancement_script.py -3 crying
python enhancement_script.py 0 crying
python enhancement_script.py 3 crying
python enhancement_script.py 6 crying
python enhancement_script.py 12 crying



python enhancement_script.py -3 doberman
python enhancement_script.py 0 doberman
python enhancement_script.py 3 doberman
python enhancement_script.py 6 doberman
python enhancement_script.py 12 doberman

python enhancement_script.py -3 german_shepherd
python enhancement_script.py 0 german_shepherd
python enhancement_script.py 3 german_shepherd
python enhancement_script.py 6 german_shepherd
python enhancement_script.py 12 german_shepherd

python enhancement_script.py -3 maltese
python enhancement_script.py 0 maltese
python enhancement_script.py 3 maltese
python enhancement_script.py 6 maltese
python enhancement_script.py 12 maltese

python enhancement_script.py -3 pistol
python enhancement_script.py 0 pistol
python enhancement_script.py 3 pistol
python enhancement_script.py 6 pistol
python enhancement_script.py 12 pistol


python enhancement_script.py -3 white
python enhancement_script.py 0 white
python enhancement_script.py 3 white
python enhancement_script.py 6 white
python enhancement_script.py 12 white