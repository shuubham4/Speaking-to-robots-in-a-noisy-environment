import os
import sys
import subprocess

inst = sys.argv
snr= str(inst[1])
noise_type = str(inst[2])

path = "./test"+"/"+snr+"/"+noise_type
outpath = "./enhanced/"+snr+"/"+noise_type

for fil in os.listdir(path):
    if fil.endswith(".wav"):
        subprocess.run(["python", "./enhance.py", "-m", "DeepFilterNet3", path+"/"+fil, "--output-dir", "./enhanced/"+snr+"/"+noise_type])

