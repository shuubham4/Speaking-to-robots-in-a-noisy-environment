from datasets import Dataset, load_dataset
from transformers import WhisperTokenizer
from transformers import WhisperProcessor
from transformers import WhisperForConditionalGeneration
from transformers import WhisperFeatureExtractor
import torch
import whisper
import sys
import soundfile as sf
import numpy as np
import os


inst=sys.argv
snr=str(inst[1])
noise_type=str(inst[2])


tokenizer = WhisperTokenizer.from_pretrained("openai/whisper-medium", language="English", task="transcribe")
processor = WhisperProcessor.from_pretrained("openai/whisper-medium", language="English", task="transcribe", sampling_rate = 16000)
feature_extractor = WhisperFeatureExtractor.from_pretrained("openai/whisper-medium", device="cuda")
model = WhisperForConditionalGeneration.from_pretrained("openai/whisper-medium", return_dict=False)
model.config.forced_decoder_ids = None 
model.config.forced_decoder_ids = processor.get_decoder_prompt_ids(language="English", task = "transcribe")
model.config.suppress_tokens = []
model.config.use_cache = False
model.config.condition_on_previous_text = False
path_dfnet = "../DFNet3/enhanced/"+snr+'/'+noise_type
path_storm = '../StoRM/HRI/Seen_noises/enhanced_set/'+snr+'/'+noise_type
file_list = os.listdir(path_dfnet)  # change path_dfnet to path_storm for transcribing the storm enhanced test set
out_file_storm = '../StoRM/HRI/Seen_noises/enhanced_set/'+snr+'/'+noise_type+'/'+'transcription.txt'
out_file_dfnet= "../DFNet3/enhanced/"+snr+'/'+noise_type+'/'+'transcription.txt'


for file_name in sorted(file_list):
    with open(os.path.join(path_dfnet,file_name), 'rb') as f1:   # change path_dfnet to path_storm for transcribing the storm enhanced test set
        if file_name.endswith(".wav"):
            audio, sample_rate = sf.read(f1)
            audio = np.array(audio)
            input_features = feature_extractor(audio, sampling_rate=16000, return_tensors="pt").input_features
            generated_ids = model.generate(inputs=input_features,no_repeat_ngram_size=4, language="English")
            transcription = processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
            with open(out_file_dfnet,"a") as f:                  # change out_file_dfnet to out_file_storm for transcribing the storm enhanced test set 

                # For StoRM enhancement
                #label = file_name.split(".")[0]
                
                # For DeepFilterNet 3 enhancement
                label = file_name.split(".")[0].split("_")[0]
                f.write(str(label).rstrip('\n'))
                f.write(" ")
                f.write(transcription)   
                f.write('\n')  