python ./loadlocal.py -3 bomb
python ./loadlocal.py 0 bomb
python ./loadlocal.py 3 bomb
python ./loadlocal.py 6 bomb
python ./loadlocal.py 12 bomb

python ./loadlocal.py -3 crowd
python ./loadlocal.py 0 crowd
python ./loadlocal.py 3 crowd
python ./loadlocal.py 6 crowd
python ./loadlocal.py 12 crowd

python ./loadlocal.py -3 forest
python ./loadlocal.py 0 forest
python ./loadlocal.py 3 forest
python ./loadlocal.py 6 forest
python ./loadlocal.py 12 forest

python ./loadlocal.py -3 heli
python ./loadlocal.py 0 heli
python ./loadlocal.py 3 heli
python ./loadlocal.py 6 heli
python ./loadlocal.py 12 heli

python ./loadlocal.py -3 bullmastif
python ./loadlocal.py 0 bullmastif
python ./loadlocal.py 3 bullmastif
python ./loadlocal.py 6 bullmastif
python ./loadlocal.py 12 bullmastif

python ./loadlocal.py -3 burst
python ./loadlocal.py 0 burst
python ./loadlocal.py 3 burst
python ./loadlocal.py 6 burst
python ./loadlocal.py 12 burst


python ./loadlocal.py -3 plane
python ./loadlocal.py 0 plane
python ./loadlocal.py 3 plane
python ./loadlocal.py 6 plane
python ./loadlocal.py 12 plane

python ./loadlocal.py -3 subway
python ./loadlocal.py 0 subway
python ./loadlocal.py 3 subway
python ./loadlocal.py 6 subway
python ./loadlocal.py 12 subway

python ./loadlocal.py -3 traffic
python ./loadlocal.py 0 traffic
python ./loadlocal.py 3 traffic
python ./loadlocal.py 6 traffic
python ./loadlocal.py 12 traffic

python ./loadlocal.py -3 chihuahua
python ./loadlocal.py 0 chihuahua
python ./loadlocal.py 3 chihuahua
python ./loadlocal.py 6 chihuahua
python ./loadlocal.py 12 chihuahua


python ./loadlocal.py -3 cooing
python ./loadlocal.py 0 cooing
python ./loadlocal.py 3 cooing
python ./loadlocal.py 6 cooing
python ./loadlocal.py 12 cooing

python ./loadlocal.py -3 crying
python ./loadlocal.py 0 crying
python ./loadlocal.py 3 crying
python ./loadlocal.py 6 crying
python ./loadlocal.py 12 crying


python ./loadlocal.py -3 doberman
python ./loadlocal.py 0 doberman
python ./loadlocal.py 3 doberman
python ./loadlocal.py 12 doberman

python ./loadlocal.py -3 german_shepherd
python ./loadlocal.py 0 german_shepherd
python ./loadlocal.py 3 german_shepherd
python ./loadlocal.py 6 german_shepherd
python ./loadlocal.py 12 german_shepherd

python ./loadlocal.py -3 maltese
python ./loadlocal.py 0 maltese
python ./loadlocal.py 3 maltese
python ./loadlocal.py 6 maltese
python ./loadlocal.py 12 maltese


python ./loadlocal.py -3 office
python ./loadlocal.py 0 office
python ./loadlocal.py 3 office
python ./loadlocal.py 6 office
python ./loadlocal.py 12 office

python ./loadlocal.py -3 pistol
python ./loadlocal.py 0 pistol
python ./loadlocal.py 3 pistol
python ./loadlocal.py 6 pistol
python ./loadlocal.py 12 pistol




