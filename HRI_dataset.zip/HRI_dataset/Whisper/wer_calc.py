from jiwer import wer
import os
import sys
import string
import array
import re


def sentence_matcher(s1,s2):
    l1 = len(s1)
    l2 = len(s2)
    diff = l1-l2
    for i in range(diff):
        s2.append("x ")
    return s2

def list2str(inp):
    sentence = ''
    for x in inp:
        sentence +=' ' + x
    return sentence

inst = sys.argv
snr=str(inst[1])
noise_type=str(inst[2])

input_storm = "../StoRM/HRI/Seen_noises/enhanced_set/"+snr+"/"+noise_type
input_dfnet = "../DFNet3/enhanced/"+snr+"/"+noise_type
ground = "../groundtruth.txt"
out_file = "./wer.txt"

for filename in os.listdir(input_dfnet):
    error = []
    if filename.endswith('transcription.txt'):  
        with open(os.path.join(input_dfnet, filename)) as f2:
            in_data=f2.readlines()
            for i in range(len(in_data)):
                if (in_data[i] != '\n'):
                    in_data[i] = re.sub(r"  ", " ", in_data[i])
                    label = in_data[i].split(" ")[0]
                    with open(ground) as fg:
                        gr_data = fg.readlines()
                        for j in range(len(gr_data)):
                            gsp = gr_data[j].split(" ")
                            if label.translate(str.maketrans('','',string.punctuation)) == gsp[0].translate(str.maketrans('','',string.punctuation)):
                                st1 = gr_data[j].translate(str.maketrans(string.punctuation, len(string.punctuation)*" "))
                                st2 = in_data[i].translate(str.maketrans(string.punctuation, len(string.punctuation)*" "))
                                st1 = re.sub('\s+',' ', st1)
                                st2 = re.sub('\s+',' ', st2)
                                gr_data[j] = st1 
                                in_data[i] = st2    
                                error.append(wer(gr_data[j].upper(), in_data[i].upper()))
                        fg.close()   

            out_txt = str(100*(sum(error)/len(error)))+ "\n"  
            f3 = open(out_file, "a")
            f3.write(out_txt)
            f3.close()
            f2.close()            
