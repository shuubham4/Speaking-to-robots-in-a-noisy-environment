python ./wer_calc.py -3 bomb
python ./wer_calc.py 0 bomb
python ./wer_calc.py 3 bomb
python ./wer_calc.py 6 bomb
python ./wer_calc.py 12 bomb

python ./wer_calc.py -3 crowd
python ./wer_calc.py 0 crowd
python ./wer_calc.py 3 crowd
python ./wer_calc.py 6 crowd
python ./wer_calc.py 12 crowd

python ./wer_calc.py -3 forest
python ./wer_calc.py 0 forest
python ./wer_calc.py 3 forest
python ./wer_calc.py 6 forest
python ./wer_calc.py 12 forest

python ./wer_calc.py -3 heli
python ./wer_calc.py 0 heli
python ./wer_calc.py 3 heli
python ./wer_calc.py 6 heli
python ./wer_calc.py 12 heli

python ./wer_calc.py -3 bullmastif
python ./wer_calc.py 0 bullmastif
python ./wer_calc.py 3 bullmastif
python ./wer_calc.py 6 bullmastif
python ./wer_calc.py 12 bullmastif

python ./wer_calc.py -3 burst
python ./wer_calc.py 0 burst
python ./wer_calc.py 3 burst
python ./wer_calc.py 6 burst
python ./wer_calc.py 12 burst

python ./wer_calc.py -3 plane
python ./wer_calc.py 0 plane
python ./wer_calc.py 3 plane
python ./wer_calc.py 6 plane
python ./wer_calc.py 12 plane

python ./wer_calc.py -3 subway
python ./wer_calc.py 0 subway
python ./wer_calc.py 3 subway
python ./wer_calc.py 6 subway
python ./wer_calc.py 12 subway

python ./wer_calc.py -3 traffic
python ./wer_calc.py 0 traffic
python ./wer_calc.py 3 traffic
python ./wer_calc.py 6 traffic
python ./wer_calc.py 12 traffic

python ./wer_calc.py -3 chihuahua
python ./wer_calc.py 0 chihuahua
python ./wer_calc.py 3 chihuahua
python ./wer_calc.py 6 chihuahua
python ./wer_calc.py 12 chihuahua


python ./wer_calc.py -3 cooing
python ./wer_calc.py 0 cooing
python ./wer_calc.py 3 cooing
python ./wer_calc.py 6 cooing
python ./wer_calc.py 12 cooing

python ./wer_calc.py -3 crying
python ./wer_calc.py 0 crying
python ./wer_calc.py 3 crying
python ./wer_calc.py 6 crying
python ./wer_calc.py 12 crying


python ./wer_calc.py -3 doberman
python ./wer_calc.py 0 doberman
python ./wer_calc.py 3 doberman
python ./wer_calc.py 6 doberman
python ./wer_calc.py 12 doberman

python ./wer_calc.py -3 german_shepherd
python ./wer_calc.py 0 german_shepherd
python ./wer_calc.py 3 german_shepherd
python ./wer_calc.py 6 german_shepherd
python ./wer_calc.py 12 german_shepherd

python ./wer_calc.py -3 maltese
python ./wer_calc.py 0 maltese
python ./wer_calc.py 3 maltese
python ./wer_calc.py 6 maltese
python ./wer_calc.py 12 maltese


python ./wer_calc.py -3 office
python ./wer_calc.py 0 office
python ./wer_calc.py 3 office
python ./wer_calc.py 6 office
python ./wer_calc.py 12 office

python ./wer_calc.py -3 pistol
python ./wer_calc.py 0 pistol
python ./wer_calc.py 3 pistol
python ./wer_calc.py 6 pistol
python ./wer_calc.py 12 pistol



